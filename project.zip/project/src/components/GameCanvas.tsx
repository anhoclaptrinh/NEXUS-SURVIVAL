import { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine, type LiveStats } from '../game/GameEngine';
import HUD from './HUD';
import LevelUpModal from './LevelUpModal';
import type { CharacterType, UpgradeOption, GameStats } from '../game/types';
import { WAVE_DURATION } from '../game/constants';
import { Pause, Play } from 'lucide-react';

interface GameCanvasProps {
  character: CharacterType;
  onGameOver: (stats: GameStats) => void;
}

interface HUDState {
  hp: number;
  maxHp: number;
  xp: number;
  xpCurrent: number;
  xpToLevel: number;
  level: number;
  wave: number;
  score: number;
  kills: number;
  time: number;
  waveProgress: number;
}

export default function GameCanvas({ character, onGameOver }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [levelUpOptions, setLevelUpOptions] = useState<UpgradeOption[] | null>(null);
  const [paused, setPaused] = useState(false);
  const [hud, setHud] = useState<HUDState>({
    hp: 100, maxHp: 100, xp: 0, xpCurrent: 0, xpToLevel: 10,
    level: 1, wave: 1, score: 0, kills: 0, time: 0, waveProgress: 0,
  });

  const handleUpgrade = useCallback((option: UpgradeOption) => {
    setLevelUpOptions(null);
    engineRef.current?.applyUpgrade(option);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new GameEngine(canvas, character);
    engineRef.current = engine;

    engine.onLevelUp = (options) => {
      setLevelUpOptions(options);
    };

    engine.onStatsUpdate = (stats: LiveStats) => {
      setHud({
        hp: stats.hp,
        maxHp: stats.maxHp,
        xp: stats.xp,
        xpCurrent: stats.xpCurrent,
        xpToLevel: stats.xpToLevel,
        level: stats.level,
        wave: stats.wave,
        score: stats.score,
        kills: stats.kills,
        time: stats.time,
        waveProgress: (stats.time % WAVE_DURATION) / WAVE_DURATION,
      });
    };

    engine.onGameOver = (stats) => {
      onGameOver(stats);
    };

    engine.start();

    return () => {
      engine.stop();
      engineRef.current = null;
    };
  }, [character, onGameOver]);

  const togglePause = () => {
    engineRef.current?.togglePause();
    setPaused(p => !p);
  };

  return (
    <div className="relative" style={{ width: 900, height: 600 }}>
      <canvas
        ref={canvasRef}
        width={900}
        height={600}
        tabIndex={0}
        className="block rounded-lg"
        style={{ outline: 'none', border: '1px solid #1a1a2e', boxShadow: '0 0 40px #00f5ff22' }}
      />

      {!levelUpOptions && (
        <>
          <HUD {...hud} />
          <button
            onClick={togglePause}
            className="absolute top-3 right-3 p-1.5 rounded transition-all hover:scale-110 pointer-events-auto z-10"
            style={{ background: '#0d0d1f', border: '1px solid #333', color: '#555' }}
          >
            {paused ? <Play size={14} /> : <Pause size={14} />}
          </button>
        </>
      )}

      {paused && !levelUpOptions && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10"
          style={{ background: 'rgba(7,7,15,0.85)' }}>
          <div className="text-4xl font-black tracking-widest mb-4" style={{ color: '#00f5ff', textShadow: '0 0 20px #00f5ff' }}>
            PAUSED
          </div>
          <button onClick={togglePause}
            className="px-8 py-3 rounded font-black tracking-widest text-sm"
            style={{ background: '#00f5ff22', border: '2px solid #00f5ff', color: '#00f5ff' }}>
            RESUME
          </button>
        </div>
      )}

      {levelUpOptions && (
        <LevelUpModal options={levelUpOptions} level={hud.level} onChoose={handleUpgrade} />
      )}
    </div>
  );
}
