import { Heart, Star, Zap, Clock, Crosshair, TrendingUp } from 'lucide-react';
import { XP_PER_LEVEL } from '../game/constants';

interface HUDProps {
  hp: number;
  maxHp: number;
  xp: number;
  level: number;
  wave: number;
  waveProgress: number;
  score: number;
  kills: number;
  time: number;
}

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, '0')}`;
}

export default function HUD({ hp, maxHp, xp, level, wave, waveProgress, score, kills, time }: HUDProps) {
  const hpRatio = Math.max(0, hp / maxHp);
  const xpStart = XP_PER_LEVEL[Math.min(level - 1, XP_PER_LEVEL.length - 1)];
  const xpEnd = XP_PER_LEVEL[Math.min(level, XP_PER_LEVEL.length - 1)];
  const xpRatio = xpEnd > xpStart ? Math.min(1, (xp - xpStart) / (xpEnd - xpStart)) : 1;
  const hpColor = hpRatio > 0.5 ? '#44ff44' : hpRatio > 0.25 ? '#ffaa00' : '#ff4444';

  return (
    <div className="absolute inset-0 pointer-events-none select-none">
      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 flex items-start justify-between p-3 gap-4">
        {/* HP */}
        <div className="flex flex-col gap-1 min-w-[180px]">
          <div className="flex items-center gap-2 mb-0.5">
            <Heart size={12} style={{ color: hpColor }} />
            <span className="text-xs font-mono tracking-widest" style={{ color: hpColor }}>
              {Math.ceil(hp)}/{maxHp}
            </span>
          </div>
          <div className="h-2.5 rounded-full overflow-hidden" style={{ background: '#1a0a0a', border: '1px solid #333' }}>
            <div className="h-full rounded-full transition-all duration-100"
              style={{ width: `${hpRatio * 100}%`, background: hpColor, boxShadow: `0 0 8px ${hpColor}` }} />
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <Star size={10} style={{ color: '#ffd700' }} />
            <span className="text-xs font-mono tracking-widest" style={{ color: '#aaa' }}>LV {level}</span>
            <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: '#111' }}>
              <div className="h-full rounded-full transition-all duration-100"
                style={{ width: `${xpRatio * 100}%`, background: '#ffd700', boxShadow: '0 0 6px #ffd700' }} />
            </div>
          </div>
        </div>

        {/* Center - score */}
        <div className="flex flex-col items-center">
          <span className="text-xs tracking-[0.3em] text-gray-500 mb-0.5">SCORE</span>
          <span className="text-2xl font-black font-mono tracking-widest" style={{ color: '#ffd700', textShadow: '0 0 15px #ffd70088' }}>
            {score.toLocaleString()}
          </span>
        </div>

        {/* Right stats */}
        <div className="flex flex-col gap-1 items-end min-w-[140px]">
          <div className="flex items-center gap-2">
            <Clock size={11} style={{ color: '#00f5ff' }} />
            <span className="text-xs font-mono tracking-widest" style={{ color: '#00f5ff' }}>{formatTime(time)}</span>
          </div>
          <div className="flex items-center gap-2">
            <Crosshair size={11} style={{ color: '#ff8800' }} />
            <span className="text-xs font-mono tracking-widest" style={{ color: '#ff8800' }}>{kills} KILLS</span>
          </div>
        </div>
      </div>

      {/* Wave indicator */}
      <div className="absolute bottom-3 left-0 right-0 flex flex-col items-center gap-1.5">
        <div className="flex items-center gap-2">
          <Zap size={12} style={{ color: '#ff4444' }} />
          <span className="text-xs font-mono tracking-[0.3em]" style={{ color: '#ff4444' }}>WAVE {wave}</span>
          <TrendingUp size={12} style={{ color: '#ff4444' }} />
        </div>
        <div className="w-48 h-1.5 rounded-full overflow-hidden" style={{ background: '#1a0a0a', border: '1px solid #333' }}>
          <div className="h-full rounded-full transition-all duration-200"
            style={{ width: `${waveProgress * 100}%`, background: 'linear-gradient(90deg, #ff4444, #ff8800)', boxShadow: '0 0 6px #ff4444' }} />
        </div>
        <span className="text-xs tracking-widest" style={{ color: '#555' }}>ESC TO PAUSE</span>
      </div>
    </div>
  );
}
