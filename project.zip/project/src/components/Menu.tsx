import { CHARACTERS } from '../game/data/characters';
import type { CharacterType } from '../game/types';
import type { LeaderboardEntry } from '../lib/supabase';
import { Shield, Zap, Target, Trophy, ChevronRight } from 'lucide-react';
import { useState } from 'react';

interface MenuProps {
  onPlay: (character: CharacterType, name: string) => void;
  topScores: LeaderboardEntry[];
}

export default function Menu({ onPlay, topScores }: MenuProps) {
  const [phase, setPhase] = useState<'main' | 'select'>('main');
  const [selectedChar, setSelectedChar] = useState<CharacterType>('apex');
  const [playerName, setPlayerName] = useState('');

  const chars = Object.values(CHARACTERS);

  if (phase === 'select') {
    return (
      <div className="menu-overlay flex flex-col items-center justify-center h-full p-8">
        <h2 className="text-3xl font-black tracking-widest mb-2" style={{ color: '#00f5ff', textShadow: '0 0 20px #00f5ff' }}>
          SELECT OPERATIVE
        </h2>
        <p className="text-gray-400 text-sm mb-8 tracking-widest">CHOOSE YOUR FIGHTER</p>

        <div className="flex gap-6 mb-8">
          {chars.map(char => (
            <button
              key={char.id}
              onClick={() => setSelectedChar(char.id)}
              className="char-card flex flex-col items-center p-6 rounded-lg border-2 transition-all duration-200"
              style={{
                borderColor: selectedChar === char.id ? char.color : '#333',
                background: selectedChar === char.id ? `${char.color}15` : '#0d0d1f',
                boxShadow: selectedChar === char.id ? `0 0 25px ${char.color}55` : 'none',
                minWidth: 160,
              }}
            >
              <div className="char-avatar mb-4" style={{ color: char.color }}>
                {char.shape === 'triangle' && <svg width="60" height="60" viewBox="-30 -30 60 60">
                  <polygon points="0,-25 20,15 -20,15" fill={char.color + '33'} stroke={char.color} strokeWidth="2.5" style={{ filter: `drop-shadow(0 0 8px ${char.color})` }} />
                </svg>}
                {char.shape === 'square' && <svg width="60" height="60" viewBox="-30 -30 60 60">
                  <rect x="-18" y="-18" width="36" height="36" fill={char.color + '33'} stroke={char.color} strokeWidth="2.5" style={{ filter: `drop-shadow(0 0 8px ${char.color})`, transform: 'rotate(45deg)' }} />
                </svg>}
              </div>
              <span className="font-black text-xl tracking-widest" style={{ color: char.color }}>{char.name}</span>
              <span className="text-xs text-gray-400 mt-1 mb-3 tracking-wider">{char.title}</span>
              <p className="text-xs text-center" style={{ color: '#888', lineHeight: '1.4' }}>{char.description}</p>

              <div className="mt-4 w-full space-y-2">
                <StatBar label="HP" value={char.id === 'tank' ? 100 : char.id === 'apex' ? 66 : 43} color={char.color} />
                <StatBar label="SPD" value={char.id === 'ghost' ? 100 : char.id === 'apex' ? 66 : 47} color={char.color} />
              </div>
            </button>
          ))}
        </div>

        <div className="flex flex-col items-center gap-4 w-full max-w-xs">
          <input
            type="text"
            placeholder="ENTER YOUR NAME"
            maxLength={20}
            value={playerName}
            onChange={e => setPlayerName(e.target.value.toUpperCase())}
            className="w-full px-4 py-3 rounded text-center font-mono tracking-widest text-sm focus:outline-none"
            style={{ background: '#0d0d1f', border: '2px solid #333', color: '#00f5ff' }}
          />
          <button
            onClick={() => onPlay(selectedChar, playerName.trim() || 'ANONYMOUS')}
            className="w-full py-4 rounded font-black tracking-widest text-lg transition-all duration-200 hover:scale-105"
            style={{
              background: `linear-gradient(135deg, ${CHARACTERS[selectedChar].color}33, ${CHARACTERS[selectedChar].glowColor}33)`,
              border: `2px solid ${CHARACTERS[selectedChar].color}`,
              color: CHARACTERS[selectedChar].color,
              boxShadow: `0 0 20px ${CHARACTERS[selectedChar].color}44`,
            }}
          >
            DEPLOY <ChevronRight className="inline" size={20} />
          </button>
          <button onClick={() => setPhase('main')} className="text-gray-500 text-sm hover:text-gray-300 tracking-wider">BACK</button>
        </div>
      </div>
    );
  }

  return (
    <div className="menu-overlay flex flex-col items-center justify-center h-full p-8">
      <div className="title-block text-center mb-8">
        <div className="text-xs tracking-[0.5em] text-gray-500 mb-2">WAVE-BASED SURVIVAL</div>
        <h1 className="text-6xl font-black tracking-widest mb-1"
          style={{ color: '#00f5ff', textShadow: '0 0 30px #00f5ff, 0 0 60px #0088ff' }}>
          NEXUS
        </h1>
        <h1 className="text-5xl font-black tracking-[0.3em]"
          style={{ color: '#ff4444', textShadow: '0 0 30px #ff4444' }}>
          SURVIVORS
        </h1>
        <div className="mt-4 text-gray-400 text-sm tracking-widest">SURVIVE. EVOLVE. DOMINATE.</div>
      </div>

      <div className="flex gap-4 mb-10 text-sm text-gray-500 tracking-widest">
        <span className="flex items-center gap-1"><Shield size={14} style={{ color: '#00f5ff' }} /> WASD TO MOVE</span>
        <span className="flex items-center gap-1"><Zap size={14} style={{ color: '#ffff00' }} /> AUTO ATTACK</span>
        <span className="flex items-center gap-1"><Target size={14} style={{ color: '#ff4444' }} /> SURVIVE WAVES</span>
      </div>

      <button
        onClick={() => setPhase('select')}
        className="px-16 py-5 mb-6 font-black text-xl tracking-widest rounded transition-all duration-200 hover:scale-105"
        style={{
          background: 'linear-gradient(135deg, #00f5ff22, #0088ff22)',
          border: '2px solid #00f5ff',
          color: '#00f5ff',
          boxShadow: '0 0 30px #00f5ff44',
        }}
      >
        ENTER THE NEXUS
      </button>

      {topScores.length > 0 && (
        <div className="leaderboard w-full max-w-md">
          <div className="flex items-center gap-2 mb-3 justify-center">
            <Trophy size={16} style={{ color: '#ffd700' }} />
            <span className="text-xs tracking-[0.3em] text-gray-400">TOP SURVIVORS</span>
          </div>
          <div className="space-y-1">
            {topScores.slice(0, 5).map((entry, i) => (
              <div key={entry.id} className="flex items-center gap-3 px-4 py-2 rounded"
                style={{ background: '#0d0d1f', border: '1px solid #1a1a2e' }}>
                <span className="font-black w-5 text-sm"
                  style={{ color: i === 0 ? '#ffd700' : i === 1 ? '#c0c0c0' : i === 2 ? '#cd7f32' : '#555' }}>
                  {i + 1}
                </span>
                <span className="flex-1 font-mono text-sm tracking-wider" style={{ color: '#ccc' }}>{entry.player_name}</span>
                <span className="text-xs tracking-wider" style={{ color: CHARACTERS[entry.character as CharacterType]?.color ?? '#888' }}>
                  {entry.character.toUpperCase()}
                </span>
                <span className="font-black text-sm" style={{ color: '#ffd700' }}>{entry.score.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs w-8 tracking-wider" style={{ color: '#666' }}>{label}</span>
      <div className="flex-1 h-1.5 rounded-full" style={{ background: '#222' }}>
        <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, background: color, boxShadow: `0 0 6px ${color}` }} />
      </div>
    </div>
  );
}
