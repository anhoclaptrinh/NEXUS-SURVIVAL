import type { UpgradeOption } from '../game/types';
import { Zap, Shield, Star } from 'lucide-react';

interface LevelUpModalProps {
  options: UpgradeOption[];
  level: number;
  onChoose: (option: UpgradeOption) => void;
}

const rarityColors = {
  common: { border: '#aaaaaa', glow: '#888888', label: 'COMMON' },
  rare: { border: '#00aaff', glow: '#0066ff', label: 'RARE' },
  epic: { border: '#ffd700', glow: '#ffaa00', label: 'EPIC' },
};

export default function LevelUpModal({ options, level, onChoose }: LevelUpModalProps) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-10"
      style={{ background: 'rgba(7,7,15,0.92)', backdropFilter: 'blur(4px)' }}>

      <div className="text-center mb-8">
        <div className="text-xs tracking-[0.4em] text-gray-500 mb-1">EVOLUTION PROTOCOL</div>
        <h2 className="text-4xl font-black tracking-widest" style={{ color: '#ffd700', textShadow: '0 0 25px #ffd700' }}>
          LEVEL {level}
        </h2>
        <div className="text-sm tracking-widest text-gray-400 mt-1">CHOOSE YOUR UPGRADE</div>
      </div>

      <div className="flex gap-5">
        {options.map((opt, i) => {
          const rc = rarityColors[opt.rarity];
          return (
            <button
              key={opt.id + i}
              onClick={() => onChoose(opt)}
              className="upgrade-card flex flex-col items-center p-6 rounded-xl transition-all duration-200 hover:scale-105"
              style={{
                background: `${rc.glow}11`,
                border: `2px solid ${rc.border}66`,
                boxShadow: `0 0 20px ${rc.glow}33`,
                minWidth: 180,
                maxWidth: 200,
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.boxShadow = `0 0 35px ${rc.glow}66`;
                (e.currentTarget as HTMLElement).style.borderColor = rc.border;
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.boxShadow = `0 0 20px ${rc.glow}33`;
                (e.currentTarget as HTMLElement).style.borderColor = `${rc.border}66`;
              }}
            >
              <div className="text-xs tracking-widest mb-3 px-2 py-0.5 rounded"
                style={{ color: rc.border, background: `${rc.border}22`, border: `1px solid ${rc.border}44` }}>
                {rc.label}
              </div>
              <div className="text-4xl mb-3">{opt.icon}</div>
              <div className="font-black text-sm tracking-widest text-center mb-2" style={{ color: rc.border }}>
                {opt.label}
              </div>
              <p className="text-xs text-center leading-relaxed" style={{ color: '#888' }}>
                {opt.description}
              </p>
              <div className="mt-4 flex items-center gap-1 text-xs" style={{ color: '#555' }}>
                {opt.type === 'weapon_new' && <><Zap size={10} style={{ color: '#00f5ff' }} /><span style={{ color: '#00f5ff' }}>NEW WEAPON</span></>}
                {opt.type === 'passive' && <><Shield size={10} style={{ color: '#44ff44' }} /><span style={{ color: '#44ff44' }}>PASSIVE</span></>}
                {opt.type === 'weapon_upgrade' && <><Star size={10} style={{ color: '#ffd700' }} /><span style={{ color: '#ffd700' }}>UPGRADE</span></>}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
