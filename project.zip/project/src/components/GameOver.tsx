import { useState, useEffect } from 'react';
import { submitScore, getTopScores, type LeaderboardEntry } from '../lib/supabase';
import type { GameStats } from '../game/types';
import { CHARACTERS } from '../game/data/characters';
import { Trophy, RotateCcw, Home, Loader } from 'lucide-react';

interface GameOverProps {
  stats: GameStats;
  playerName: string;
  onRestart: () => void;
  onMenu: () => void;
}

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}m ${sec}s`;
}

export default function GameOver({ stats, playerName, onRestart, onMenu }: GameOverProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);
  const char = CHARACTERS[stats.character];

  useEffect(() => {
    async function submit() {
      await submitScore({
        player_name: playerName,
        character: stats.character,
        score: stats.score,
        waves_survived: stats.wave,
        time_survived: stats.timeSurvived,
        kills: stats.kills,
      });
      setSubmitted(true);
      const scores = await getTopScores(8);
      setLeaderboard(scores);
      setLoading(false);
    }
    submit();
  }, []);

  const rank = leaderboard.findIndex(e => e.score === stats.score && e.player_name === playerName) + 1;

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-20 p-6"
      style={{ background: 'rgba(7,7,15,0.97)', backdropFilter: 'blur(8px)' }}>

      <div className="text-center mb-6">
        <div className="text-xs tracking-[0.4em] text-gray-600 mb-2">OPERATIVE DOWN</div>
        <h2 className="text-5xl font-black tracking-widest mb-1" style={{ color: '#ff4444', textShadow: '0 0 30px #ff4444' }}>
          GAME OVER
        </h2>
        <div className="text-sm tracking-widest mt-1" style={{ color: char.color }}>{playerName} — {char.name}</div>
      </div>

      <div className="grid grid-cols-4 gap-3 mb-6 w-full max-w-lg">
        <StatCard label="SCORE" value={stats.score.toLocaleString()} color="#ffd700" />
        <StatCard label="KILLS" value={String(stats.kills)} color="#ff8800" />
        <StatCard label="WAVE" value={String(stats.wave)} color="#ff4444" />
        <StatCard label="TIME" value={formatTime(stats.timeSurvived)} color="#00f5ff" />
      </div>

      {rank > 0 && rank <= 10 && (
        <div className="mb-4 px-6 py-2 rounded text-center"
          style={{ background: '#ffd70011', border: '1px solid #ffd70044' }}>
          <Trophy size={14} className="inline mr-1" style={{ color: '#ffd700' }} />
          <span className="text-sm tracking-widest" style={{ color: '#ffd700' }}>
            #{rank} ON LEADERBOARD
          </span>
        </div>
      )}

      {loading && (
        <div className="flex items-center gap-2 mb-4 text-gray-500 text-sm">
          <Loader size={14} className="animate-spin" />
          <span className="tracking-widest">{submitted ? 'LOADING SCORES...' : 'SUBMITTING SCORE...'}</span>
        </div>
      )}

      {!loading && leaderboard.length > 0 && (
        <div className="w-full max-w-lg mb-6">
          <div className="text-xs tracking-[0.3em] text-gray-500 mb-2 text-center">TOP SURVIVORS</div>
          <div className="space-y-1">
            {leaderboard.map((entry, i) => {
              const isMe = entry.score === stats.score && entry.player_name === playerName;
              return (
                <div key={entry.id} className="flex items-center gap-3 px-3 py-1.5 rounded"
                  style={{
                    background: isMe ? '#ffd70011' : '#0d0d1f',
                    border: `1px solid ${isMe ? '#ffd70055' : '#1a1a2e'}`,
                  }}>
                  <span className="font-black w-5 text-sm"
                    style={{ color: i === 0 ? '#ffd700' : i === 1 ? '#c0c0c0' : i === 2 ? '#cd7f32' : '#555' }}>
                    {i + 1}
                  </span>
                  <span className="flex-1 font-mono text-xs tracking-wider" style={{ color: isMe ? '#ffd700' : '#ccc' }}>
                    {entry.player_name}
                  </span>
                  <span className="text-xs" style={{ color: CHARACTERS[entry.character as typeof stats.character]?.color ?? '#888' }}>
                    {entry.character.toUpperCase()}
                  </span>
                  <span className="font-black text-sm" style={{ color: isMe ? '#ffd700' : '#888' }}>
                    {entry.score.toLocaleString()}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="flex gap-4">
        <button onClick={onRestart}
          className="flex items-center gap-2 px-8 py-3 rounded font-black tracking-widest text-sm transition-all hover:scale-105"
          style={{ background: '#00f5ff22', border: '2px solid #00f5ff', color: '#00f5ff', boxShadow: '0 0 20px #00f5ff33' }}>
          <RotateCcw size={16} /> RETRY
        </button>
        <button onClick={onMenu}
          className="flex items-center gap-2 px-8 py-3 rounded font-black tracking-widest text-sm transition-all hover:scale-105"
          style={{ background: '#ff444422', border: '2px solid #ff4444', color: '#ff4444' }}>
          <Home size={16} /> MENU
        </button>
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex flex-col items-center p-3 rounded-lg"
      style={{ background: `${color}11`, border: `1px solid ${color}44` }}>
      <span className="text-xs tracking-widest mb-1" style={{ color: '#666' }}>{label}</span>
      <span className="font-black text-base font-mono" style={{ color }}>{value}</span>
    </div>
  );
}
