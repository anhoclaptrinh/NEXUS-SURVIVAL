import type { CharacterType, ActiveWeapon } from '../types';

export interface CharacterDef {
  id: CharacterType;
  name: string;
  title: string;
  description: string;
  color: string;
  glowColor: string;
  hp: number;
  speed: number;
  startingWeapon: ActiveWeapon;
  shape: 'triangle' | 'circle' | 'square';
}

export const CHARACTERS: Record<CharacterType, CharacterDef> = {
  apex: {
    id: 'apex',
    name: 'APEX',
    title: 'The Gunslinger',
    description: 'Balanced stats with rapid-fire revolver. Perfect for beginners.',
    color: '#00f5ff',
    glowColor: '#0088ff',
    hp: 100,
    speed: 220,
    shape: 'triangle',
    startingWeapon: { type: 'revolver', level: 1, timer: 0, cooldown: 0.7 },
  },
  ghost: {
    id: 'ghost',
    name: 'GHOST',
    title: 'The Specter',
    description: 'Blazing fast but fragile. Spinning shurikens cut through crowds.',
    color: '#ff44ff',
    glowColor: '#aa00ff',
    hp: 65,
    speed: 340,
    shape: 'triangle',
    startingWeapon: { type: 'shuriken', level: 1, timer: 0, cooldown: 0.4 },
  },
  tank: {
    id: 'tank',
    name: 'TANK',
    title: 'The Juggernaut',
    description: 'Massive health pool. Orbiting void orbs crush everything nearby.',
    color: '#44ff44',
    glowColor: '#00aa00',
    hp: 200,
    speed: 160,
    shape: 'square',
    startingWeapon: { type: 'orb', level: 1, timer: 0, cooldown: 3.0 },
  },
};
