import type { EnemyType } from '../types';

export interface EnemyDef {
  type: EnemyType;
  name: string;
  radius: number;
  baseHp: number;
  speed: number;
  damage: number;
  xpValue: number;
  scoreValue: number;
  color: string;
  glowColor: string;
  shootTimer?: number;
}

export const ENEMIES: Record<EnemyType, EnemyDef> = {
  crawler: {
    type: 'crawler',
    name: 'Crawler',
    radius: 16,
    baseHp: 30,
    speed: 75,
    damage: 10,
    xpValue: 3,
    scoreValue: 10,
    color: '#ff4444',
    glowColor: '#ff0000',
  },
  rusher: {
    type: 'rusher',
    name: 'Rusher',
    radius: 12,
    baseHp: 15,
    speed: 160,
    damage: 15,
    xpValue: 4,
    scoreValue: 15,
    color: '#ff8800',
    glowColor: '#ff5500',
  },
  bloater: {
    type: 'bloater',
    name: 'Bloater',
    radius: 26,
    baseHp: 120,
    speed: 45,
    damage: 30,
    xpValue: 8,
    scoreValue: 35,
    color: '#44ff44',
    glowColor: '#00aa00',
  },
  shooter: {
    type: 'shooter',
    name: 'Shooter',
    radius: 14,
    baseHp: 25,
    speed: 60,
    damage: 8,
    xpValue: 6,
    scoreValue: 25,
    color: '#ff44ff',
    glowColor: '#cc00cc',
    shootTimer: 2.5,
  },
  boss: {
    type: 'boss',
    name: 'NEXUS CORE',
    radius: 48,
    baseHp: 2000,
    speed: 90,
    damage: 50,
    xpValue: 100,
    scoreValue: 500,
    color: '#ffff00',
    glowColor: '#ffaa00',
    shootTimer: 1.5,
  },
};

export const WAVE_ENEMY_TABLES: Record<number, { type: EnemyType; weight: number }[]> = {
  1: [{ type: 'crawler', weight: 10 }],
  2: [{ type: 'crawler', weight: 7 }, { type: 'rusher', weight: 3 }],
  3: [{ type: 'crawler', weight: 5 }, { type: 'rusher', weight: 4 }, { type: 'bloater', weight: 1 }],
  4: [{ type: 'crawler', weight: 4 }, { type: 'rusher', weight: 4 }, { type: 'bloater', weight: 2 }],
  5: [{ type: 'crawler', weight: 3 }, { type: 'rusher', weight: 3 }, { type: 'bloater', weight: 2 }, { type: 'shooter', weight: 2 }],
  99: [{ type: 'crawler', weight: 2 }, { type: 'rusher', weight: 3 }, { type: 'bloater', weight: 2 }, { type: 'shooter', weight: 3 }],
};
