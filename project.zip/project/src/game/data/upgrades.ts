import type { UpgradeOption, WeaponType, PassiveType } from '../types';

const W = (weaponType: WeaponType, label: string, desc: string, icon: string, rarity: UpgradeOption['rarity']): UpgradeOption => ({
  id: `weapon_${weaponType}`,
  type: 'weapon_new',
  weaponType,
  label,
  description: desc,
  icon,
  rarity,
});

const P = (passiveType: PassiveType, value: number, label: string, desc: string, icon: string, rarity: UpgradeOption['rarity']): UpgradeOption => ({
  id: `passive_${passiveType}_${value}`,
  type: 'passive',
  passiveType,
  passiveValue: value,
  label,
  description: desc,
  icon,
  rarity,
});

export const ALL_UPGRADES: UpgradeOption[] = [
  W('revolver', 'REVOLVER', 'Fires rapid shots at the nearest enemy', '🔫', 'common'),
  W('shuriken', 'SHURIKEN', 'Spinning blades orbit your position', '⭐', 'common'),
  W('laser', 'LASER BEAM', 'Piercing energy beam sweeps through enemies', '⚡', 'rare'),
  W('orb', 'VOID ORB', 'Orbiting orbs of destruction', '🔮', 'rare'),
  W('missile', 'HOMING MISSILE', 'Self-guided missiles track enemies relentlessly', '🚀', 'epic'),
  W('aura', 'DEATH AURA', 'Continuous damage to all nearby enemies', '💀', 'epic'),

  P('speed', 15, 'SPEED BOOST', '+15 movement speed', '💨', 'common'),
  P('speed', 25, 'OVERDRIVE', '+25 movement speed — become untouchable', '💨', 'rare'),
  P('damage', 0.2, 'POWER SURGE', '+20% damage to all weapons', '⚔️', 'common'),
  P('damage', 0.4, 'CRITICAL MASS', '+40% damage to all weapons', '⚔️', 'rare'),
  P('hp', 25, 'REINFORCED', '+25 max HP and full heal', '❤️', 'common'),
  P('hp', 50, 'FORTIFIED', '+50 max HP and full heal', '❤️', 'rare'),
  P('cooldown', 0.15, 'RAPID FIRE', '-15% weapon cooldowns', '⏱️', 'rare'),
  P('cooldown', 0.25, 'STORM MODE', '-25% weapon cooldowns', '⏱️', 'epic'),
  P('pierce', 1, 'PENETRATOR', '+1 pierce — shots pass through more enemies', '🔰', 'rare'),
  P('pickup_range', 30, 'COLLECTOR', '+30 XP gem pickup range', '💎', 'common'),
  P('magnet', 1, 'MAGNETISM', 'XP gems fly toward you automatically', '🧲', 'epic'),
];

export function getRandomUpgrades(
  count: number,
  ownedWeapons: WeaponType[],
  _ownedPassives: PassiveType[]
): UpgradeOption[] {
  const available = ALL_UPGRADES.filter(u => {
    if (u.type === 'weapon_new' && ownedWeapons.includes(u.weaponType!)) return false;
    return true;
  });

  const shuffled = [...available].sort(() => Math.random() - 0.5);

  const epic = shuffled.filter(u => u.rarity === 'epic');
  const rare = shuffled.filter(u => u.rarity === 'rare');
  const common = shuffled.filter(u => u.rarity === 'common');

  const pool: UpgradeOption[] = [];
  if (epic.length > 0 && Math.random() < 0.25) pool.push(epic[0]);
  if (rare.length > 0 && pool.length < count) pool.push(rare[0]);
  while (pool.length < count && common.length > 0) {
    const item = common.splice(Math.floor(Math.random() * common.length), 1)[0];
    if (!pool.find(p => p.id === item.id)) pool.push(item);
  }
  while (pool.length < count && shuffled.length > 0) {
    const item = shuffled.splice(0, 1)[0];
    if (!pool.find(p => p.id === item.id)) pool.push(item);
  }

  return pool.slice(0, count);
}
