export interface Vec2 {
  x: number;
  y: number;
}

export interface Entity {
  id: number;
  x: number;
  y: number;
  radius: number;
  alive: boolean;
}

export interface PlayerState extends Entity {
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  speed: number;
  xp: number;
  level: number;
  kills: number;
  score: number;
  invincibleTimer: number;
  weapons: ActiveWeapon[];
  passives: PassiveEffect[];
  character: CharacterType;
}

export interface EnemyState extends Entity {
  type: EnemyType;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  xpValue: number;
  scoreValue: number;
  vx: number;
  vy: number;
  shootTimer?: number;
  phase?: number;
}

export interface ProjectileState extends Entity {
  vx: number;
  vy: number;
  damage: number;
  piercing: number;
  hitsLeft: number;
  hitEnemies: Set<number>;
  lifetime: number;
  maxLifetime: number;
  weaponType: WeaponType;
  ownedBy: 'player' | 'enemy';
  homing?: boolean;
  angle?: number;
  orbitRadius?: number;
  orbitAngle?: number;
  orbitSpeed?: number;
}

export interface GemState extends Entity {
  value: number;
  magnetized?: boolean;
}

export interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  type: 'spark' | 'glow' | 'text';
  text?: string;
}

export interface ActiveWeapon {
  type: WeaponType;
  level: number;
  timer: number;
  cooldown: number;
}

export interface PassiveEffect {
  type: PassiveType;
  value: number;
}

export type CharacterType = 'apex' | 'ghost' | 'tank';

export type WeaponType = 'revolver' | 'shuriken' | 'laser' | 'orb' | 'missile' | 'aura';

export type EnemyType = 'crawler' | 'rusher' | 'bloater' | 'shooter' | 'boss';

export type PassiveType = 'speed' | 'damage' | 'hp' | 'pickup_range' | 'pierce' | 'cooldown' | 'magnet';

export type UpgradeType = 'weapon_new' | 'weapon_upgrade' | 'passive';

export interface UpgradeOption {
  id: string;
  type: UpgradeType;
  weaponType?: WeaponType;
  passiveType?: PassiveType;
  passiveValue?: number;
  label: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic';
}

export type GamePhase = 'menu' | 'character_select' | 'playing' | 'level_up' | 'paused' | 'game_over';

export interface GameStats {
  score: number;
  kills: number;
  wave: number;
  timeSurvived: number;
  level: number;
  character: CharacterType;
}
