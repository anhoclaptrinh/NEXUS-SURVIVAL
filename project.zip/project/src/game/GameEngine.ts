import { CANVAS_WIDTH, CANVAS_HEIGHT, WORLD_SIZE, PLAYER_RADIUS, GEM_RADIUS, GEM_PICKUP_RADIUS, NEON_COLORS, XP_PER_LEVEL, MAX_ENEMIES, WAVE_DURATION, BASE_ENEMY_SPAWN_RATE } from './constants';
import { getRandomUpgrades } from './data/upgrades';
import type { PlayerState, EnemyState, ProjectileState, GemState, Particle, UpgradeOption, GameStats, CharacterType, EnemyType, WeaponType } from './types';
import { CHARACTERS } from './data/characters';
import { ENEMIES, WAVE_ENEMY_TABLES } from './data/enemies';

let nextId = 1;
const uid = () => nextId++;

function dist(ax: number, ay: number, bx: number, by: number) {
  const dx = ax - bx, dy = ay - by;
  return Math.sqrt(dx * dx + dy * dy);
}

function normalize(x: number, y: number): [number, number] {
  const d = Math.sqrt(x * x + y * y);
  return d > 0 ? [x / d, y / d] : [0, 0];
}

export interface LiveStats {
  hp: number;
  maxHp: number;
  xp: number;
  xpCurrent: number;
  xpToLevel: number;
  wave: number;
  score: number;
  time: number;
  kills: number;
  level: number;
  character: CharacterType;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private player!: PlayerState;
  private enemies: EnemyState[] = [];
  private projectiles: ProjectileState[] = [];
  private gems: GemState[] = [];
  private particles: Particle[] = [];
  private keys: Set<string> = new Set();
  private cameraX = 0;
  private cameraY = 0;
  private wave = 1;
  private waveTimer = 0;
  private enemySpawnTimer = 0;
  private totalTime = 0;
  private bossSpawned = false;
  private screenShake = 0;
  private damageMultiplier = 1;
  private cooldownMultiplier = 1;
  private pickupRange = GEM_PICKUP_RADIUS;
  private magnet = false;
  private lastTime = 0;
  private rafId = 0;
  private paused = false;
  private orbitAngles: Map<string, number> = new Map();

  onLevelUp?: (options: UpgradeOption[]) => void;
  onStatsUpdate?: (stats: LiveStats) => void;
  onGameOver?: (stats: GameStats) => void;

  constructor(canvas: HTMLCanvasElement, character: CharacterType) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.initPlayer(character);
    this.setupInput();
    this.canvas.focus();
  }

  private initPlayer(character: CharacterType) {
    const def = CHARACTERS[character];
    this.player = {
      id: uid(),
      x: WORLD_SIZE / 2,
      y: WORLD_SIZE / 2,
      radius: PLAYER_RADIUS,
      alive: true,
      vx: 0,
      vy: 0,
      hp: def.hp,
      maxHp: def.hp,
      speed: def.speed,
      xp: 0,
      level: 1,
      kills: 0,
      score: 0,
      invincibleTimer: 0,
      weapons: [{ ...def.startingWeapon }],
      passives: [],
      character,
    };
  }

  private setupInput() {
    const onKey = (e: KeyboardEvent, down: boolean) => {
      this.keys[down ? 'add' : 'delete'](e.key.toLowerCase());
      if (e.key === 'Escape' && !down) this.togglePause();
    };
    window.addEventListener('keydown', e => onKey(e, true));
    window.addEventListener('keyup', e => onKey(e, false));
  }

  togglePause() {
    this.paused = !this.paused;
    if (!this.paused) {
      this.lastTime = performance.now();
      this.loop(this.lastTime);
    }
  }

  start() {
    this.lastTime = performance.now();
    this.rafId = requestAnimationFrame(t => this.loop(t));
  }

  stop() {
    cancelAnimationFrame(this.rafId);
    window.removeEventListener('keydown', () => {});
    window.removeEventListener('keyup', () => {});
  }

  applyUpgrade(option: UpgradeOption) {
    if (option.type === 'weapon_new' && option.weaponType) {
      const wt = option.weaponType;
      const cooldowns: Record<WeaponType, number> = {
        revolver: 0.7, shuriken: 0.4, laser: 1.5, orb: 3.0, missile: 1.2, aura: 0.5,
      };
      this.player.weapons.push({ type: wt, level: 1, timer: 0, cooldown: cooldowns[wt] });
    } else if (option.type === 'passive' && option.passiveType !== undefined && option.passiveValue !== undefined) {
      const pt = option.passiveType;
      const pv = option.passiveValue;
      const existing = this.player.passives.find(p => p.type === pt);
      if (existing) existing.value += pv;
      else this.player.passives.push({ type: pt, value: pv });

      if (pt === 'speed') this.player.speed += pv;
      else if (pt === 'damage') this.damageMultiplier += pv;
      else if (pt === 'hp') { this.player.maxHp += pv; this.player.hp = Math.min(this.player.hp + pv, this.player.maxHp); }
      else if (pt === 'cooldown') this.cooldownMultiplier = Math.max(0.3, this.cooldownMultiplier - pv);
      else if (pt === 'pickup_range') this.pickupRange += pv;
      else if (pt === 'magnet') this.magnet = true;
      else if (pt === 'pierce') { /* pierce is applied per-projectile */ }
    }
    this.paused = false;
    this.lastTime = performance.now();
    this.rafId = requestAnimationFrame(t => this.loop(t));
  }

  private loop(timestamp: number) {
    if (this.paused) return;
    const dt = Math.min((timestamp - this.lastTime) / 1000, 0.05);
    this.lastTime = timestamp;
    this.update(dt);
    this.render();
    this.rafId = requestAnimationFrame(t => this.loop(t));
  }

  private update(dt: number) {
    if (!this.player.alive) return;
    this.totalTime += dt;
    this.waveTimer += dt;
    if (this.waveTimer >= WAVE_DURATION) {
      this.wave++;
      this.waveTimer = 0;
      this.bossSpawned = false;
      this.spawnWaveBoss();
    }
    if (!this.bossSpawned && this.waveTimer >= WAVE_DURATION * 0.5) {
      this.bossSpawned = true;
    }

    this.updatePlayer(dt);
    this.updateWeapons(dt);
    this.updateEnemies(dt);
    this.updateProjectiles(dt);
    this.updateGems(dt);
    this.updateParticles(dt);
    this.spawnEnemies(dt);
    this.screenShake = Math.max(0, this.screenShake - dt * 15);

    this.onStatsUpdate?.({
      hp: this.player.hp,
      maxHp: this.player.maxHp,
      xp: this.player.xp,
      xpCurrent: this.player.xp - XP_PER_LEVEL[Math.min(this.player.level - 1, XP_PER_LEVEL.length - 1)],
      xpToLevel: XP_PER_LEVEL[Math.min(this.player.level, XP_PER_LEVEL.length - 1)] - XP_PER_LEVEL[Math.min(this.player.level - 1, XP_PER_LEVEL.length - 1)],
      wave: this.wave,
      score: this.player.score,
      time: this.totalTime,
      kills: this.player.kills,
      level: this.player.level,
      character: this.player.character,
    });
  }

  private updatePlayer(dt: number) {
    const p = this.player;
    let dx = 0, dy = 0;
    if (this.keys.has('arrowleft') || this.keys.has('a')) dx -= 1;
    if (this.keys.has('arrowright') || this.keys.has('d')) dx += 1;
    if (this.keys.has('arrowup') || this.keys.has('w')) dy -= 1;
    if (this.keys.has('arrowdown') || this.keys.has('s')) dy += 1;

    const [nx, ny] = normalize(dx, dy);
    p.vx = nx * p.speed;
    p.vy = ny * p.speed;
    p.x = Math.max(p.radius, Math.min(WORLD_SIZE - p.radius, p.x + p.vx * dt));
    p.y = Math.max(p.radius, Math.min(WORLD_SIZE - p.radius, p.y + p.vy * dt));

    if (p.invincibleTimer > 0) p.invincibleTimer -= dt;

    this.cameraX = p.x - CANVAS_WIDTH / 2;
    this.cameraY = p.y - CANVAS_HEIGHT / 2;
    this.cameraX = Math.max(0, Math.min(WORLD_SIZE - CANVAS_WIDTH, this.cameraX));
    this.cameraY = Math.max(0, Math.min(WORLD_SIZE - CANVAS_HEIGHT, this.cameraY));

    for (const enemy of this.enemies) {
      if (!enemy.alive) continue;
      const d = dist(p.x, p.y, enemy.x, enemy.y);
      if (d < p.radius + enemy.radius && p.invincibleTimer <= 0) {
        p.hp -= enemy.damage;
        p.invincibleTimer = 0.8;
        this.screenShake = 0.4;
        this.spawnParticles(p.x, p.y, '#ff4444', 6, 'spark');
        if (enemy.type === 'bloater') {
          enemy.hp = 0;
          enemy.alive = false;
          this.onEnemyDeath(enemy);
        }
        if (p.hp <= 0) {
          p.alive = false;
          this.onGameOver?.({
            score: p.score,
            kills: p.kills,
            wave: this.wave,
            timeSurvived: Math.floor(this.totalTime),
            level: p.level,
            character: p.character,
          });
          cancelAnimationFrame(this.rafId);
        }
      }
    }
  }

  private updateWeapons(dt: number) {
    const p = this.player;
    const pierce = (p.passives.find(x => x.type === 'pierce')?.value ?? 0) + 1;

    for (const weapon of p.weapons) {
      weapon.timer -= dt;
      if (weapon.timer > 0) continue;
      weapon.timer = weapon.cooldown * this.cooldownMultiplier;

      if (weapon.type === 'revolver') this.fireRevolver(pierce);
      else if (weapon.type === 'shuriken') this.fireShuriken();
      else if (weapon.type === 'laser') this.fireLaser(pierce);
      else if (weapon.type === 'orb') this.fireOrb();
      else if (weapon.type === 'missile') this.fireMissile();
      else if (weapon.type === 'aura') this.pulseAura();
    }
  }

  private nearestEnemy(): EnemyState | null {
    let best: EnemyState | null = null;
    let bestDist = Infinity;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const d = dist(this.player.x, this.player.y, e.x, e.y);
      if (d < bestDist) { bestDist = d; best = e; }
    }
    return best;
  }

  private fireRevolver(pierce: number) {
    const target = this.nearestEnemy();
    if (!target) return;
    const [dx, dy] = normalize(target.x - this.player.x, target.y - this.player.y);
    const spd = 500;
    const baseDmg = 20 * this.damageMultiplier;
    this.projectiles.push({
      id: uid(), x: this.player.x, y: this.player.y,
      vx: dx * spd, vy: dy * spd,
      radius: 5, alive: true,
      damage: baseDmg, piercing: pierce, hitsLeft: pierce,
      hitEnemies: new Set(), lifetime: 0, maxLifetime: 1.5,
      weaponType: 'revolver', ownedBy: 'player',
    });
  }

  private fireShuriken() {
    const count = 3;
    const baseDmg = 12 * this.damageMultiplier;
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i / count) + this.totalTime * 2;
      const spd = 300;
      this.projectiles.push({
        id: uid(), x: this.player.x, y: this.player.y,
        vx: Math.cos(angle) * spd, vy: Math.sin(angle) * spd,
        radius: 8, alive: true,
        damage: baseDmg, piercing: 999, hitsLeft: 999,
        hitEnemies: new Set(), lifetime: 0, maxLifetime: 0.6,
        weaponType: 'shuriken', ownedBy: 'player',
      });
    }
  }

  private fireLaser(pierce: number) {
    const target = this.nearestEnemy();
    if (!target) return;
    const [dx, dy] = normalize(target.x - this.player.x, target.y - this.player.y);
    const spd = 900;
    const baseDmg = 35 * this.damageMultiplier;
    for (let i = -1; i <= 1; i++) {
      const spread = i * 0.08;
      const ax = dx * Math.cos(spread) - dy * Math.sin(spread);
      const ay = dx * Math.sin(spread) + dy * Math.cos(spread);
      this.projectiles.push({
        id: uid(), x: this.player.x, y: this.player.y,
        vx: ax * spd, vy: ay * spd,
        radius: 4, alive: true,
        damage: baseDmg, piercing: pierce + 2, hitsLeft: pierce + 2,
        hitEnemies: new Set(), lifetime: 0, maxLifetime: 0.8,
        weaponType: 'laser', ownedBy: 'player',
      });
    }
  }

  private fireOrb() {
    const key = `orb_${uid()}`;
    const startAngle = this.orbitAngles.get('orb') ?? 0;
    const baseDmg = 45 * this.damageMultiplier;
    const orb: ProjectileState = {
      id: uid(), x: this.player.x, y: this.player.y,
      vx: 0, vy: 0,
      radius: 14, alive: true,
      damage: baseDmg, piercing: 999, hitsLeft: 999,
      hitEnemies: new Set(), lifetime: 0, maxLifetime: 4,
      weaponType: 'orb', ownedBy: 'player',
      orbitRadius: 90, orbitAngle: startAngle, orbitSpeed: 2.5,
    };
    this.projectiles.push(orb);
    void key;
  }

  private fireMissile() {
    const target = this.nearestEnemy();
    if (!target) return;
    const [dx, dy] = normalize(target.x - this.player.x, target.y - this.player.y);
    const baseDmg = 60 * this.damageMultiplier;
    this.projectiles.push({
      id: uid(), x: this.player.x, y: this.player.y,
      vx: dx * 200, vy: dy * 200,
      radius: 7, alive: true,
      damage: baseDmg, piercing: 1, hitsLeft: 1,
      hitEnemies: new Set(), lifetime: 0, maxLifetime: 3,
      weaponType: 'missile', ownedBy: 'player',
      homing: true,
    });
  }

  private pulseAura() {
    const baseDmg = 8 * this.damageMultiplier;
    const radius = 120;
    for (const enemy of this.enemies) {
      if (!enemy.alive) continue;
      if (dist(this.player.x, this.player.y, enemy.x, enemy.y) < radius) {
        this.dealDamageToEnemy(enemy, baseDmg);
      }
    }
    this.spawnParticles(this.player.x, this.player.y, '#9933ff', 8, 'glow');
  }

  private updateEnemies(dt: number) {
    const p = this.player;
    for (const enemy of this.enemies) {
      if (!enemy.alive) continue;
      const [dx, dy] = normalize(p.x - enemy.x, p.y - enemy.y);
      enemy.x += dx * enemy.speed * dt;
      enemy.y += dy * enemy.speed * dt;
      enemy.x = Math.max(enemy.radius, Math.min(WORLD_SIZE - enemy.radius, enemy.x));
      enemy.y = Math.max(enemy.radius, Math.min(WORLD_SIZE - enemy.radius, enemy.y));

      if (enemy.type === 'shooter' && enemy.shootTimer !== undefined) {
        enemy.shootTimer -= dt;
        if (enemy.shootTimer <= 0) {
          enemy.shootTimer = ENEMIES.shooter.shootTimer!;
          const d = dist(enemy.x, enemy.y, p.x, p.y);
          if (d < 600) {
            const [ex, ey] = normalize(p.x - enemy.x, p.y - enemy.y);
            this.projectiles.push({
              id: uid(), x: enemy.x, y: enemy.y,
              vx: ex * 220, vy: ey * 220,
              radius: 5, alive: true,
              damage: enemy.damage, piercing: 1, hitsLeft: 1,
              hitEnemies: new Set(), lifetime: 0, maxLifetime: 3,
              weaponType: 'revolver', ownedBy: 'enemy',
            });
          }
        }
      }

      if (enemy.type === 'boss' && enemy.shootTimer !== undefined) {
        enemy.shootTimer -= dt;
        if (enemy.shootTimer <= 0) {
          enemy.shootTimer = ENEMIES.boss.shootTimer!;
          for (let i = 0; i < 8; i++) {
            const angle = (Math.PI * 2 * i / 8) + this.totalTime;
            this.projectiles.push({
              id: uid(), x: enemy.x, y: enemy.y,
              vx: Math.cos(angle) * 180, vy: Math.sin(angle) * 180,
              radius: 6, alive: true,
              damage: 25, piercing: 1, hitsLeft: 1,
              hitEnemies: new Set(), lifetime: 0, maxLifetime: 4,
              weaponType: 'revolver', ownedBy: 'enemy',
            });
          }
        }
      }
    }
    this.enemies = this.enemies.filter(e => e.alive);
  }

  private updateProjectiles(dt: number) {
    for (const proj of this.projectiles) {
      if (!proj.alive) continue;
      proj.lifetime += dt;
      if (proj.lifetime >= proj.maxLifetime) { proj.alive = false; continue; }

      if (proj.orbitRadius !== undefined && proj.orbitAngle !== undefined) {
        proj.orbitAngle! += (proj.orbitSpeed ?? 2.5) * dt;
        proj.x = this.player.x + Math.cos(proj.orbitAngle!) * proj.orbitRadius!;
        proj.y = this.player.y + Math.sin(proj.orbitAngle!) * proj.orbitRadius!;
      } else {
        if (proj.homing) {
          const target = this.nearestEnemy();
          if (target) {
            const [dx, dy] = normalize(target.x - proj.x, target.y - proj.y);
            const speed = Math.sqrt(proj.vx * proj.vx + proj.vy * proj.vy);
            const turn = 4 * dt;
            proj.vx = proj.vx * (1 - turn) + dx * speed * turn;
            proj.vy = proj.vy * (1 - turn) + dy * speed * turn;
          }
        }
        proj.x += proj.vx * dt;
        proj.y += proj.vy * dt;
      }

      if (proj.ownedBy === 'player') {
        for (const enemy of this.enemies) {
          if (!enemy.alive) continue;
          if (proj.hitEnemies.has(enemy.id)) continue;
          if (dist(proj.x, proj.y, enemy.x, enemy.y) < proj.radius + enemy.radius) {
            proj.hitEnemies.add(enemy.id);
            proj.hitsLeft--;
            this.dealDamageToEnemy(enemy, proj.damage);
            this.spawnParticles(enemy.x, enemy.y, '#ffffff', 3, 'spark');
            if (proj.hitsLeft <= 0) { proj.alive = false; break; }
          }
        }
      } else {
        const p = this.player;
        if (p.invincibleTimer <= 0 && dist(proj.x, proj.y, p.x, p.y) < proj.radius + p.radius) {
          p.hp -= proj.damage;
          p.invincibleTimer = 0.5;
          this.screenShake = 0.25;
          proj.alive = false;
          this.spawnParticles(p.x, p.y, '#ff4444', 5, 'spark');
          if (p.hp <= 0) {
            p.alive = false;
            this.onGameOver?.({
              score: p.score, kills: p.kills, wave: this.wave,
              timeSurvived: Math.floor(this.totalTime), level: p.level, character: p.character,
            });
            cancelAnimationFrame(this.rafId);
          }
        }
      }
    }
    this.projectiles = this.projectiles.filter(p => p.alive);
  }

  private dealDamageToEnemy(enemy: EnemyState, damage: number) {
    enemy.hp -= damage;
    this.spawnDamageNumber(enemy.x, enemy.y - enemy.radius, Math.floor(damage));
    if (enemy.hp <= 0) {
      enemy.alive = false;
      this.onEnemyDeath(enemy);
    }
  }

  private onEnemyDeath(enemy: EnemyState) {
    this.player.kills++;
    this.player.score += enemy.scoreValue * this.wave;
    const gemCount = enemy.type === 'boss' ? 20 : enemy.type === 'bloater' ? 4 : 1;
    for (let i = 0; i < gemCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const r = Math.random() * 20;
      this.gems.push({
        id: uid(),
        x: enemy.x + Math.cos(angle) * r,
        y: enemy.y + Math.sin(angle) * r,
        radius: GEM_RADIUS,
        alive: true,
        value: enemy.xpValue,
      });
    }
    const def = ENEMIES[enemy.type];
    this.spawnParticles(enemy.x, enemy.y, def.glowColor, enemy.type === 'boss' ? 30 : 8, 'spark');
  }

  private updateGems(dt: number) {
    const p = this.player;
    for (const gem of this.gems) {
      if (!gem.alive) continue;
      const d = dist(p.x, p.y, gem.x, gem.y);
      if (this.magnet || d < this.pickupRange) {
        const [dx, dy] = normalize(p.x - gem.x, p.y - gem.y);
        const speed = this.magnet ? 400 : 250;
        gem.x += dx * speed * dt;
        gem.y += dy * speed * dt;
        gem.magnetized = true;
      }
      if (dist(p.x, p.y, gem.x, gem.y) < p.radius + gem.radius) {
        gem.alive = false;
        this.addXP(gem.value);
      }
    }
    this.gems = this.gems.filter(g => g.alive);
  }

  private addXP(amount: number) {
    this.player.xp += amount;
    const maxLevel = XP_PER_LEVEL.length - 1;
    while (this.player.level < maxLevel) {
      const needed = XP_PER_LEVEL[this.player.level];
      if (this.player.xp >= needed) {
        this.player.level++;
        this.triggerLevelUp();
        return;
      } else break;
    }
  }

  private triggerLevelUp() {
    this.paused = true;
    cancelAnimationFrame(this.rafId);
    const ownedWeapons = this.player.weapons.map(w => w.type);
    const ownedPassives = this.player.passives.map(p => p.type);
    const options = getRandomUpgrades(3, ownedWeapons, ownedPassives);
    this.onLevelUp?.(options);
  }

  // ── THAY ĐỔI 1: spawn rate gấp đôi, wave vô hạn ──────────────────────────
  private spawnEnemies(dt: number) {
    if (this.enemies.length >= MAX_ENEMIES) return;
    this.enemySpawnTimer -= dt;
    // Gấp đôi spawn rate bằng cách chia 2 thời gian chờ
    const spawnRate = Math.max(0.15, (BASE_ENEMY_SPAWN_RATE - this.wave * 0.08) / 2);
    if (this.enemySpawnTimer > 0) return;
    this.enemySpawnTimer = spawnRate;

    // Wave vô hạn: dùng modulo để lấy bảng, không bị giới hạn
    const tableKey = ((this.wave - 1) % 99) + 1 as keyof typeof WAVE_ENEMY_TABLES;
    const table = WAVE_ENEMY_TABLES[tableKey] ?? WAVE_ENEMY_TABLES[99];
    const totalWeight = table.reduce((s, t) => s + t.weight, 0);
    let rand = Math.random() * totalWeight;
    let chosenType: EnemyType = 'crawler';
    for (const entry of table) {
      rand -= entry.weight;
      if (rand <= 0) { chosenType = entry.type; break; }
    }

    // Spawn 2 quái mỗi lần thay vì 1
    this.spawnEnemy(chosenType);
    this.spawnEnemy(chosenType);
  }

  private spawnEnemy(type: EnemyType) {
    const def = ENEMIES[type];
    const margin = 60;
    const side = Math.floor(Math.random() * 4);
    let x = this.player.x, y = this.player.y;
    const offset = 450 + Math.random() * 150;
    if (side === 0) { x = this.player.x + (Math.random() - 0.5) * 900; y = this.player.y - offset; }
    else if (side === 1) { x = this.player.x + offset; y = this.player.y + (Math.random() - 0.5) * 900; }
    else if (side === 2) { x = this.player.x + (Math.random() - 0.5) * 900; y = this.player.y + offset; }
    else { x = this.player.x - offset; y = this.player.y + (Math.random() - 0.5) * 900; }

    x = Math.max(margin, Math.min(WORLD_SIZE - margin, x));
    y = Math.max(margin, Math.min(WORLD_SIZE - margin, y));

    const hpScale = 1 + (this.wave - 1) * 0.2;
    this.enemies.push({
      id: uid(), x, y, radius: def.radius,
      alive: true, type,
      hp: def.baseHp * hpScale, maxHp: def.baseHp * hpScale,
      speed: def.speed, damage: def.damage,
      xpValue: def.xpValue, scoreValue: def.scoreValue,
      vx: 0, vy: 0,
      shootTimer: def.shootTimer,
      phase: Math.random() * Math.PI * 2,
    });
  }

  // ── THAY ĐỔI 2: spawn 2 boss mỗi wave thay vì 1, wave vô hạn ─────────────
  private spawnWaveBoss() {
    // Cứ mỗi 3 wave spawn boss, wave vô hạn dùng modulo
    if (this.wave % 3 === 0) {
      this.spawnEnemy('boss');
      this.spawnEnemy('boss');
    }
  }

  private updateParticles(dt: number) {
    for (const p of this.particles) {
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.92;
      p.vy *= 0.92;
    }
    this.particles = this.particles.filter(p => p.life > 0);
  }

  private spawnParticles(x: number, y: number, color: string, count: number, type: Particle['type']) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 40 + Math.random() * 120;
      this.particles.push({
        id: uid(), x, y,
        vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
        life: 0.3 + Math.random() * 0.4,
        maxLife: 0.5,
        color, size: 2 + Math.random() * 4, type,
      });
    }
  }

  private spawnDamageNumber(x: number, y: number, value: number) {
    this.particles.push({
      id: uid(), x: x + (Math.random() - 0.5) * 20, y,
      vx: (Math.random() - 0.5) * 20, vy: -60,
      life: 0.8, maxLife: 0.8,
      color: value > 50 ? '#ffff00' : '#ffffff',
      size: value > 50 ? 14 : 11, type: 'text', text: String(value),
    });
  }

  private render() {
    const ctx = this.ctx;
    const W = CANVAS_WIDTH, H = CANVAS_HEIGHT;
    const shakeX = this.screenShake > 0 ? (Math.random() - 0.5) * this.screenShake * 12 : 0;
    const shakeY = this.screenShake > 0 ? (Math.random() - 0.5) * this.screenShake * 12 : 0;

    ctx.save();
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = NEON_COLORS.bg;
    ctx.fillRect(0, 0, W, H);

    ctx.translate(shakeX, shakeY);
    ctx.translate(-this.cameraX, -this.cameraY);

    this.renderGrid(ctx);
    this.renderGems(ctx);
    this.renderProjectiles(ctx);
    this.renderEnemies(ctx);
    this.renderPlayer(ctx);
    this.renderParticles(ctx);
    ctx.restore();
  }

  private renderGrid(ctx: CanvasRenderingContext2D) {
    const gridSize = 80;
    ctx.strokeStyle = NEON_COLORS.grid;
    ctx.lineWidth = 1;
    ctx.globalAlpha = 0.4;
    const startX = Math.floor(this.cameraX / gridSize) * gridSize;
    const startY = Math.floor(this.cameraY / gridSize) * gridSize;
    for (let x = startX; x < this.cameraX + CANVAS_WIDTH + gridSize; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, this.cameraY);
      ctx.lineTo(x, this.cameraY + CANVAS_HEIGHT);
      ctx.stroke();
    }
    for (let y = startY; y < this.cameraY + CANVAS_HEIGHT + gridSize; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(this.cameraX, y);
      ctx.lineTo(this.cameraX + CANVAS_WIDTH, y);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  private renderGems(ctx: CanvasRenderingContext2D) {
    for (const gem of this.gems) {
      if (!gem.alive) continue;
      if (!this.isVisible(gem.x, gem.y, gem.radius)) continue;
      ctx.save();
      ctx.shadowBlur = 12;
      ctx.shadowColor = NEON_COLORS.gemGlow;
      ctx.fillStyle = NEON_COLORS.gem;
      ctx.beginPath();
      const r = gem.radius;
      ctx.moveTo(gem.x, gem.y - r);
      ctx.lineTo(gem.x + r * 0.6, gem.y);
      ctx.lineTo(gem.x, gem.y + r);
      ctx.lineTo(gem.x - r * 0.6, gem.y);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  private renderEnemies(ctx: CanvasRenderingContext2D) {
    for (const enemy of this.enemies) {
      if (!enemy.alive) continue;
      if (!this.isVisible(enemy.x, enemy.y, enemy.radius + 10)) continue;
      const def = ENEMIES[enemy.type];
      ctx.save();
      ctx.shadowBlur = enemy.type === 'boss' ? 30 : 15;
      ctx.shadowColor = def.glowColor;
      ctx.fillStyle = def.color;
      ctx.strokeStyle = def.glowColor;
      ctx.lineWidth = 2;

      if (enemy.type === 'boss') {
        ctx.beginPath();
        for (let i = 0; i < 8; i++) {
          const a = (Math.PI * 2 * i / 8) + this.totalTime * 0.5;
          const r = i % 2 === 0 ? enemy.radius : enemy.radius * 0.6;
          if (i === 0) ctx.moveTo(enemy.x + Math.cos(a) * r, enemy.y + Math.sin(a) * r);
          else ctx.lineTo(enemy.x + Math.cos(a) * r, enemy.y + Math.sin(a) * r);
        }
        ctx.closePath();
      } else if (enemy.type === 'bloater') {
        ctx.beginPath();
        ctx.arc(enemy.x, enemy.y, enemy.radius, 0, Math.PI * 2);
      } else if (enemy.type === 'rusher') {
        const a = Math.atan2(this.player.y - enemy.y, this.player.x - enemy.x);
        ctx.beginPath();
        ctx.moveTo(enemy.x + Math.cos(a) * enemy.radius, enemy.y + Math.sin(a) * enemy.radius);
        ctx.lineTo(enemy.x + Math.cos(a + 2.4) * enemy.radius * 0.7, enemy.y + Math.sin(a + 2.4) * enemy.radius * 0.7);
        ctx.lineTo(enemy.x + Math.cos(a - 2.4) * enemy.radius * 0.7, enemy.y + Math.sin(a - 2.4) * enemy.radius * 0.7);
        ctx.closePath();
      } else {
        ctx.beginPath();
        ctx.rect(enemy.x - enemy.radius * 0.8, enemy.y - enemy.radius * 0.8, enemy.radius * 1.6, enemy.radius * 1.6);
      }
      ctx.fill();
      ctx.stroke();

      const hpRatio = enemy.hp / enemy.maxHp;
      if (hpRatio < 1 && hpRatio > 0) {
        const bw = enemy.radius * 2.5;
        const bh = 4;
        const bx = enemy.x - bw / 2;
        const by = enemy.y - enemy.radius - 10;
        ctx.fillStyle = '#333';
        ctx.fillRect(bx, by, bw, bh);
        ctx.fillStyle = hpRatio > 0.5 ? '#44ff44' : hpRatio > 0.25 ? '#ffaa00' : '#ff4444';
        ctx.fillRect(bx, by, bw * hpRatio, bh);
      }
      ctx.restore();
    }
  }

  private renderPlayer(ctx: CanvasRenderingContext2D) {
    const p = this.player;
    const def = CHARACTERS[p.character];
    if (p.invincibleTimer > 0 && Math.floor(p.invincibleTimer * 10) % 2 === 0) return;

    ctx.save();
    ctx.shadowBlur = 25;
    ctx.shadowColor = def.glowColor;
    ctx.strokeStyle = def.color;
    ctx.lineWidth = 3;
    ctx.fillStyle = def.color + '44';

    if (def.shape === 'triangle') {
      const angle = (p.vx !== 0 || p.vy !== 0)
        ? Math.atan2(p.vy, p.vx) - Math.PI / 2
        : -Math.PI / 2;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(angle);
      ctx.beginPath();
      ctx.moveTo(0, -p.radius);
      ctx.lineTo(p.radius * 0.8, p.radius * 0.7);
      ctx.lineTo(-p.radius * 0.8, p.radius * 0.7);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    } else if (def.shape === 'square') {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(this.totalTime * 0.5);
      ctx.beginPath();
      ctx.rect(-p.radius * 0.8, -p.radius * 0.8, p.radius * 1.6, p.radius * 1.6);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    } else {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }

    ctx.restore();

    for (const proj of this.projectiles) {
      if (!proj.alive || proj.ownedBy !== 'player') continue;
      if (proj.orbitRadius === undefined) continue;
      if (!this.isVisible(proj.x, proj.y, proj.radius)) continue;
      ctx.save();
      ctx.shadowBlur = 20;
      ctx.shadowColor = '#8800ff';
      ctx.fillStyle = '#aa44ff';
      ctx.beginPath();
      ctx.arc(proj.x, proj.y, proj.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderProjectiles(ctx: CanvasRenderingContext2D) {
    for (const proj of this.projectiles) {
      if (!proj.alive || proj.orbitRadius !== undefined) continue;
      if (!this.isVisible(proj.x, proj.y, proj.radius + 4)) continue;
      ctx.save();
      const colors: Record<string, string> = {
        revolver: proj.ownedBy === 'enemy' ? '#ff4444' : '#00ffaa',
        shuriken: '#ffff00',
        laser: '#00aaff',
        missile: '#ff8800',
        orb: '#aa44ff',
        aura: '#9933ff',
      };
      const color = colors[proj.weaponType] ?? '#ffffff';
      ctx.shadowBlur = 12;
      ctx.shadowColor = color;
      ctx.fillStyle = color;
      ctx.beginPath();
      if (proj.weaponType === 'shuriken') {
        ctx.save();
        ctx.translate(proj.x, proj.y);
        ctx.rotate(proj.lifetime * 10);
        for (let i = 0; i < 4; i++) {
          const a = (Math.PI * 2 * i / 4);
          ctx.moveTo(Math.cos(a) * proj.radius, Math.sin(a) * proj.radius);
          ctx.lineTo(Math.cos(a + 0.5) * proj.radius * 0.4, Math.sin(a + 0.5) * proj.radius * 0.4);
        }
        ctx.restore();
        ctx.beginPath();
        ctx.arc(proj.x, proj.y, proj.radius, 0, Math.PI * 2);
      } else if (proj.weaponType === 'missile') {
        ctx.save();
        ctx.translate(proj.x, proj.y);
        const a = Math.atan2(proj.vy, proj.vx);
        ctx.rotate(a);
        ctx.beginPath();
        ctx.moveTo(proj.radius * 1.5, 0);
        ctx.lineTo(-proj.radius, proj.radius * 0.6);
        ctx.lineTo(-proj.radius, -proj.radius * 0.6);
        ctx.closePath();
        ctx.restore();
      } else {
        ctx.arc(proj.x, proj.y, proj.radius, 0, Math.PI * 2);
      }
      ctx.fill();
      ctx.restore();
    }
  }

  private renderParticles(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      if (!this.isVisible(p.x, p.y, 20)) continue;
      const alpha = p.life / p.maxLife;
      ctx.globalAlpha = Math.max(0, alpha);
      if (p.type === 'text' && p.text) {
        ctx.fillStyle = p.color;
        ctx.font = `bold ${p.size}px monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(p.text, p.x, p.y);
      } else {
        ctx.fillStyle = p.color;
        ctx.shadowBlur = 8;
        ctx.shadowColor = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * alpha, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    }
    ctx.globalAlpha = 1;
    ctx.textAlign = 'left';
  }

  private isVisible(x: number, y: number, r: number): boolean {
    return (
      x + r > this.cameraX &&
      x - r < this.cameraX + CANVAS_WIDTH &&
      y + r > this.cameraY &&
      y - r < this.cameraY + CANVAS_HEIGHT
    );
  }

  getPlayerHP() { return { hp: this.player.hp, maxHp: this.player.maxHp }; }
  getWave() { return this.wave; }
  getTotalTime() { return this.totalTime; }
}