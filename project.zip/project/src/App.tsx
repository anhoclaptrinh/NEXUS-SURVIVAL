import { useState, useEffect, useCallback } from 'react';
import Menu from './components/Menu';
import GameCanvas from './components/GameCanvas';
import GameOver from './components/GameOver';
import type { CharacterType, GameStats, GamePhase } from './game/types';
import { getTopScores, type LeaderboardEntry } from './lib/supabase';

export default function App() {
  const [phase, setPhase] = useState<GamePhase>('menu');
  const [character, setCharacter] = useState<CharacterType>('apex');
  const [playerName, setPlayerName] = useState('ANONYMOUS');
  const [gameStats, setGameStats] = useState<GameStats | null>(null);
  const [topScores, setTopScores] = useState<LeaderboardEntry[]>([]);
  const [gameKey, setGameKey] = useState(0);

  useEffect(() => {
    getTopScores(8).then(setTopScores);
  }, []);

  const handlePlay = useCallback((char: CharacterType, name: string) => {
    setCharacter(char);
    setPlayerName(name);
    setPhase('playing');
  }, []);

  const handleGameOver = useCallback((stats: GameStats) => {
    setGameStats(stats);
    setPhase('game_over');
  }, []);

  const handleRestart = useCallback(() => {
    setGameKey(k => k + 1);
    setPhase('playing');
  }, []);

  const handleMenu = useCallback(() => {
    getTopScores(8).then(setTopScores);
    setPhase('menu');
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#030308' }}>
      <div className="relative overflow-hidden rounded-xl"
        style={{
          width: 900,
          height: 600,
          background: '#07070f',
          boxShadow: '0 0 60px #00f5ff22, 0 0 120px #00f5ff11',
        }}>

        <div className="absolute inset-0 pointer-events-none" style={{
          background: 'radial-gradient(ellipse at 50% 0%, #00f5ff08 0%, transparent 70%)',
        }} />

        {phase === 'menu' && (
          <Menu onPlay={handlePlay} topScores={topScores} />
        )}

        {phase === 'playing' && (
          <GameCanvas
            key={gameKey}
            character={character}
            onGameOver={handleGameOver}
          />
        )}

        {phase === 'game_over' && gameStats && (
          <>
            <GameCanvas
              key={gameKey}
              character={character}
              onGameOver={() => {}}
            />
            <GameOver
              stats={gameStats}
              playerName={playerName}
              onRestart={handleRestart}
              onMenu={handleMenu}
            />
          </>
        )}
      </div>
    </div>
  );
}
