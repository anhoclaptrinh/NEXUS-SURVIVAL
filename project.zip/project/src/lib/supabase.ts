import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseKey);

export interface LeaderboardEntry {
  id: string;
  player_name: string;
  character: string;
  score: number;
  waves_survived: number;
  time_survived: number;
  kills: number;
  created_at: string;
}

export async function submitScore(entry: Omit<LeaderboardEntry, 'id' | 'created_at'>) {
  const { error } = await supabase.from('leaderboard').insert(entry);
  return error;
}

export async function getTopScores(limit = 10): Promise<LeaderboardEntry[]> {
  const { data } = await supabase
    .from('leaderboard')
    .select('*')
    .order('score', { ascending: false })
    .limit(limit);
  return data ?? [];
}
