/*
  # Create Leaderboard Table - NEXUS SURVIVORS

  ## Summary
  Sets up the leaderboard for the game NEXUS SURVIVORS.

  ## New Tables
  - `leaderboard`
    - `id` (uuid, PK): Unique record ID
    - `player_name` (text): Player's display name
    - `character` (text): Character used (apex/ghost/tank)
    - `score` (integer): Final score
    - `waves_survived` (integer): Number of waves completed
    - `time_survived` (integer): Seconds survived
    - `kills` (integer): Total enemies killed
    - `created_at` (timestamptz): When the run was submitted

  ## Security
  - RLS enabled with public read (leaderboard is public info)
  - INSERT allowed for anonymous users (no auth required to submit a score)
*/

CREATE TABLE IF NOT EXISTS leaderboard (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_name text NOT NULL DEFAULT 'Anonymous',
  character text NOT NULL DEFAULT 'apex',
  score integer NOT NULL DEFAULT 0,
  waves_survived integer NOT NULL DEFAULT 0,
  time_survived integer NOT NULL DEFAULT 0,
  kills integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE leaderboard ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view leaderboard"
  ON leaderboard FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can submit a score"
  ON leaderboard FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    length(player_name) > 0 AND
    length(player_name) <= 20 AND
    score >= 0
  );

CREATE INDEX IF NOT EXISTS leaderboard_score_idx ON leaderboard (score DESC);
